set +e
setprop ota.progress.current 30
setprop ota.progress.next 52

echo "install best1700_watch.bin"
time " dd if=/ota/best1700_watch.bin of=/dev/hifi bs=32768 verify"
if [ $? -ne 0 ]
then
    echo "dd best1700_watch.bin failed"
    reboot
fi
setprop ota.progress.current 52
setprop ota.progress.next 78

echo "install nuttx_ap.bin"
time " dd if=/ota/nuttx_ap.bin of=/dev/ap bs=32768 verify"
if [ $? -ne 0 ]
then
    echo "dd nuttx_ap.bin failed"
    reboot
fi
setprop ota.progress.current 78
setprop ota.progress.next 79

echo "install smf.json"
time " dd if=/ota/smf.json of=/dev/smfjson bs=32768 verify"
if [ $? -ne 0 ]
then
    echo "dd smf.json failed"
    reboot
fi
setprop ota.progress.current 79
setprop ota.progress.next 79

echo "install smf.json"
time " dd if=/ota/smf.json of=/dev/bth_smfjson bs=32768 verify"
if [ $? -ne 0 ]
then
    echo "dd smf.json failed"
    reboot
fi
setprop ota.progress.current 79
setprop ota.progress.next 79

echo "install pil_algo_up_dll.dll"
time " dd if=/ota/pil_algo_up_dll.dll of=/dev/updll bs=32768 verify"
if [ $? -ne 0 ]
then
    echo "dd pil_algo_up_dll.dll failed"
    reboot
fi
setprop ota.progress.current 79
setprop ota.progress.next 87

echo "install nuttx_bth.bin"
time " dd if=/ota/nuttx_bth.bin of=/dev/bth bs=32768 verify"
if [ $? -ne 0 ]
then
    echo "dd nuttx_bth.bin failed"
    reboot
fi
setprop ota.progress.current 87
setprop ota.progress.next 100

echo "install nuttx_apc1.bin"
time " dd if=/ota/nuttx_apc1.bin of=/dev/apc1 bs=32768 verify"
if [ $? -ne 0 ]
then
    echo "dd nuttx_apc1.bin failed"
    reboot
fi
setprop ota.progress.current 100
